# Color-detection-python
Colour detection is the process of detecting the name of any color. 
